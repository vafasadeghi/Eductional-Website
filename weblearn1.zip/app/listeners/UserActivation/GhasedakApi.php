<?php

namespace App\Listeners\UserActivation;

class GhasedakApi
{

    /**
     * @param mixed $env
     */
    public function __construct($env)
    {
    }
}
