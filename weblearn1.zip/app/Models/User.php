<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable,HasRole;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name', 'email', 'password', 'phone','active' , 'api_token','viptime'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public  function  isActive(){
        return $this->vipTime > Carbon::now() ? true : false;
    }

    public function article()
    {
        return $this->hasMany(Article::class);
    }
    public function course()
    {
        return $this->hasMany(Course::class);
    }
    public function payments(){

        return $this->hasMany(Payment::class);
    }


    public function isAdmin()
    {
        return $this->level == 'admin' ? true : false;
  }
    public function activationCode()
    {
        return $this->hasMany(ActivationCode::class);
    }

    public function comments()
    {
        return $this->hasMany(Comment::class);
    }

    public function checkLearning($course)
    {
        return !! Learning::where('user_id' , $this->id)->where('course_id' , $course->id)->first();
    }}
