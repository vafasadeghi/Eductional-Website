<?php

function user(){
    return auth()->user();
}
