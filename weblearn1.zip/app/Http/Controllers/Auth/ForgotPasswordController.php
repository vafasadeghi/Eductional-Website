<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Str;

class ForgotPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset emails and
    | includes a trait which assists in sending these notifications from
    | your application to your users. Feel free to explore this trait.
    |
    */

    use SendsPasswordResetEmails;

    public function sendResetLinkPhone(Request $request)
    {
            $this->validate($request);


            $user = User::wherePhone($request->input('phone'))->first();

            if ($user){
                    $token = $this->createToken($user , config('auth.passwords.users.table'));

                    return back()->with('statua' , 'لینک فعال سازی به شماره تلفن شما ارسال شد');

            }
            return back()->withErrors([
                'کاربرس با این شماره وجود ندارد']);
    }

    /**
     * Validate the email for the given request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return void
     */
    protected function validatePhone(\Illuminate\Http\Request $request)
    {
        $request->validate(['phone' => 'required|digits:11']);
    }

    private function createToken($user, $tableName)
    {
        $passwordTable = DB::table($tableName);
        $password = $passwordTable->wherePhone($user->phone);
        $token = Str::random(60);

        if($password->first()) {
            $password->update(['token' => $token , 'created_at' => Carbon::now()]);
        } else {
            $passwordTable->insert(
                ['phone' => $user->phone , 'token' => $token , 'created_at' => Carbon::now()]
            );
        }

        return $token;
    }
    /**
     * @param $user
     * @param $token
     */
    private function sendSmsLink($user, $token)
    {
        try {
            $api = new KavenegarApi("daea339a8bfb34b475f7442fca1b05");
            $result = $api->send("5000121212", $user->phone, route('password.reset', $token));
        } catch (ApiException $e) {
            Log::error($e->errorMessage());
        } catch (HttpException $e) {
            Log::error($e->errorMessage());
        }
    }
}
